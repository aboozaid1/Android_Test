import { View, Text } from 'react-native'
import React from 'react'

const Reels = () => {
  return (
    <View>
      <Text>Reels</Text>
    </View>
  )
}

export default Reels